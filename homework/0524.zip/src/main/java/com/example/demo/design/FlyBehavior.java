package com.example.demo.design;
//abstract 생략해도 괜찮아. 왜냐면 싹다 추상메소드 뿐이야
//인터페이스가 추상클래스 보다 더 추상적이다 
//나는 아직 설계할 년차는 아니잖아
public interface FlyBehavior {
	public void fly();
}
