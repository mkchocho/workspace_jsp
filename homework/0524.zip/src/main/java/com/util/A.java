package com.util;

public class A {

	public static void main(String[] args) {
		System.out.println(10/3);
		System.out.println(10.0/3);
		

	}

}
